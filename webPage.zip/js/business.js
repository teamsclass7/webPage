$(window).resize(function(){
   var wwidth = $(window).width();
   if(wwidth <= 1024){
      $(function(){
         var chk = true;
         $(".main_menu>li").click(function(){
            if(chk == true){
               $(this).children(".sub1").fadeIn(200);
            }else if(chk == false){
               $(this).children(".sub1").fadeOut(200);
            }
            chk = !chk;
         });
      });
   }else{
      $(".main_menu>li").hover(function(){
         $(this).children(".sub1").fadeIn(200);
      },function(){
         $(this).children(".sub1").fadeOut(200);
      });
      $(".sub1>li").hover(function(){
         $(this).children(".sub2").fadeIn(200);
      },function(){
         $(this).children(".sub2").fadeOut(200);
      });
   }
});


$(function(){
   $("#menu").click(function(){
      $(this).toggleClass("aniMenu");
      $(".main_menu").fadeToggle(300);
   });
});


function prevFunc(){
   $(".slideWrap").prepend($(".slideWrap li").last().clone().css("transition","all .3s"));
   $(".slideWrap li").last().remove();
};

function nextFunc(){
   $(".slideWrap").append($(".slideWrap li").first().clone().css("transition","all .3s"));
   $(".slideWrap li").first().remove();
};

